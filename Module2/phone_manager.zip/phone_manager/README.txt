- Chuong trinh Quan Ly Dien Thoai:

- Dien thoai bao gom: id, ten, gia, nha san xuat
Dien thoai chia thanh 2 loai: 
+ chinh hang: thoi gian bao hanh, ma so bao hanh
+ xach tay: quoc gia, trang thai

- Menu: 
1. them moi 
2. sua
3. xoa
4. hien thi
5. tim kiem theo ten
6. sap xep them gia
7. thoat

- Chuc nang: 
+ them moi: tuy chon them xach tay hoac chinh hang, id tu tang
+ sua: yeu cau nguoi dung nhap ID de sua
+ xoa: yeu cau nhap id de xoa, neu id ko co thi throw ra NotFoundPhoneException va yeu cau nhap lai
+ hien thi: ca 2 loai chinh hang va xach tay
+ tim kiem: tim kiem theo ten
+ sap xep theo gia tang dan 
+ thoat: thoat khoi chuong trinh

- Validate:
+ tat ca cac truong bat buoc nhap
+ ten dien thoai phai bat dau bang DT
+ gia > 50

- File
co chuc nang luu vao file

------------------

- Demo tham khao:
+ folder one_file: viet vao 1 file phone.csv
+ folder two_file: viet vao 2 file authentic.csv va hand.csv

. folder phone_p1_collection: buoc 1, chi lam den collection, chua co phan doc ghi file
. folder phone_p2_file: buoc 2, phat trien them phan doc ghi file, chua co validation + exception
. folder phone_p3_validation_exception: buoc 3, day du cac chuc nang yeu cau co ban



