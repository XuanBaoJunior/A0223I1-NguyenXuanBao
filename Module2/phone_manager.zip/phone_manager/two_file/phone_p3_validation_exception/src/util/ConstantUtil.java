package util;

public interface ConstantUtil {
    interface PATH{
        String AUTHENTIC = "src/data/authenticPhone.csv";
        String HAND = "src/data/handPhone.csv";
    }
}
